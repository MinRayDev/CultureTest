from core.client import Client
from core.game import Game

client: Client = Client()
game: Game = Game()
