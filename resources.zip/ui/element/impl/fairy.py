import time

import pygame
from pygame import Surface

from ui.element.element import Element
from utils.time_util import has_elapsed


class Fairy(Element):
    sprite: Surface
    sprites: dict[str, Surface]
    position: int
    relative_position: int
    limit: int
    wing_flap: float

    def __init__(self, sprites: dict[str, Surface], x: int, y: int, limit: int = 3):
        self.sprite = sprites["fairy_0"]
        self.sprites = sprites
        self.rectangle = self.sprite.get_rect()
        self.position = 0
        self.relative_position = 0
        self.limit = limit
        self.wing_flap = 0
        super().__init__(x, y, rectangle=self.rectangle)

    def draw(self, surface: pygame.Surface, **kwargs) -> None:
        surface.blit(self.sprite, self.rectangle)

    def activity(self, events: list[pygame.event.Event]) -> None:
        if has_elapsed(self.wing_flap, 0.25):
            self.wing_flap = time.time()
            if self.sprite == self.sprites["fairy_0"]:
                self.sprite = self.sprites["fairy_1"]
            else:
                self.sprite = self.sprites["fairy_0"]

    def move(self, y: int) -> None:
        self.rectangle.y = y
