import pygame.transform
from pygame import Surface

import references
from ui.element.impl.text import Text
from utils.sprites import load, resize


class HUD:
    """Class 'HUD' is the HUD of the game."""
    x: int
    y: int
    width: int
    height: int
    sprites: dict[str, Surface]
    forest_shadow: Surface
    hearts: list[Surface]

    def __init__(self):
        """Constructor of the class 'HUD'."""
        self.x = 0
        self.y = 0
        client_surface: Surface = references.client.surface
        self.width = client_surface.get_width()
        self.height = client_surface.get_height()
        self.sprites = {}
        sprites = load("resources/hud")
        for key, value in sprites.items():
            self.sprites[key] = resize(value, 4)
        # self.forest_shadow = pygame.mask.from_surface(sprites["forest_mask"]).to_surface()
        self.forest_shadow = sprites["forest_mask"]
        i: int = 30
        pygame.transform.threshold(self.forest_shadow, self.forest_shadow, (255, 255, 255, 255), (1, 1, 1, 255),
                                   (i, i, i, 120))
        pygame.transform.threshold(self.forest_shadow, self.forest_shadow, (i, i, i, 120), (1, 1, 1, 255), (0, 0, 0, 0))
        self.default_forest_shadow = self.forest_shadow.copy()
        self.hearts = []
        self.set_life(3)

    def draw(self, surface: Surface) -> None:
        """Draws the HUD on the screen.

            :param surface: The surface on which the HUD is drawn.
            :type surface: Surface.
        """

        for i, heart in enumerate(self.hearts):
            surface.blit(heart, (self.width - self.width // 30 - (i * self.width // 30), self.height // 20))
        Text("Correct: " + str(references.game.good_answers), self.width - self.width // 15, self.height // 10,
             (0, 255, 0)).draw(surface)
        Text("Fps: " + str(references.client.clock.get_fps()), self.width - self.width // 15, self.height // 80,
             (0, 255, 0)).draw(surface)
        if references.game.player.ghost:
            Text("Ghost Mod", self.width - self.width // 8, self.height // 7, (0, 255, 255)).draw(surface)

    def set_life(self, life: int) -> None:
        """Sets the life of the player.

            :param life: The life of the player.
            :type life: int.
        """
        self.hearts.clear()
        match life:
            case 3:
                self.hearts.append(self.sprites["heart"])
                self.hearts.append(self.sprites["heart"])
                self.hearts.append(self.sprites["heart"])
            case 2:
                self.hearts.append(self.sprites["heart"])
                self.hearts.append(self.sprites["heart"])
                self.hearts.append(self.sprites["heart_slot"])
            case 1:
                self.hearts.append(self.sprites["heart"])
                self.hearts.append(self.sprites["heart_slot"])
                self.hearts.append(self.sprites["heart_slot"])
