import enum


class ColorReference(enum.Enum):
    collision = (255, 0, 0, 255)
    forward = (0, 255, 255, 255)
    backward = (0, 255, 0, 255)
    yforward = (255, 255, 0, 255)
    question = (125, 125, 125, 255)
    answer1 = (125, 0, 0, 255)
    answer2 = (0, 125, 0, 255)
    answer3 = (0, 0, 125, 255)
    final_text = (125, 0, 125, 255)

    collisions = (
        collision,
        question,
        answer1,
        answer2,
        answer3
    )

    def get_value(self):
        return self.value

    def get_name(self):
        return self.name

    @staticmethod
    def get_interactions() -> tuple['ColorReference', ...]:
        return ColorReference.question, ColorReference.answer1, ColorReference.answer2, ColorReference.answer3, ColorReference.final_text
