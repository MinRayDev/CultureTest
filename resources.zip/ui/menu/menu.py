from typing import Optional, TYPE_CHECKING

from pygame import Surface
from pygame.event import Event
from utils.sprites import load, resize

if TYPE_CHECKING:
    from core.sound import Sound
    from pygame.mixer import Channel


class Menu:
    parent: Optional['Menu']
    sprites: dict[str, Surface]
    music: Optional[str]
    sounds: dict[str, 'Sound']

    def __init__(self, parent: Optional['Menu'], resources_path: str, ratio: float = 4):
        self.parent = parent
        from core.sound import Sound
        self.sprites = {}
        self.sounds = Sound.load_sounds(resources_path)
        self.music = None
        if len(self.sounds) > 0:
            self.music = list(self.sounds.keys())[0]

        s__ = load(resources_path)
        for key, value in s__.items():
            self.sprites[key] = resize(value, ratio)

    def draw(self, surface: Surface) -> None:
        ...

    def action(self, events: list[Event]) -> None:
        ...

    def play(self, channel: 'Channel', loops: int = 0):
        channel.stop()
        channel.play(self.sounds[self.music], loops=loops)
