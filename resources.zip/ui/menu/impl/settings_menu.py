from typing import TYPE_CHECKING, Callable, Optional

import pygame
from pygame import Surface
from pygame.event import Event

from ui.element.impl.choice import Choice
from ui.element.impl.settings_menu.choice_bar import ChoiceBar
from ui.element.impl.outlined_text import OutlinedText
from ui.element.impl.fairy import Fairy
from ui.element.impl.settings_menu.choice_box import ChoiceBox
from ui.menu.menu import Menu
from utils.sprites import get_center

if TYPE_CHECKING:
    from pygame.mixer import Channel


class SettingsMenu(Menu):
    ratio: float
    menu_title: OutlinedText
    choices: list[Choice]
    fairy: Fairy

    def __init__(self, parent: Optional['Menu']):
        from references import client, game
        self.ratio = client.surface.get_height()/224
        super().__init__(parent, "./resources/menu/settings", ratio=self.ratio)
        self.menu_title = OutlinedText("ECRAN DES PARAMETRES", int(112*self.ratio), int(23*self.ratio), (255, 255, 255), (0, 0, 200), int(15*self.ratio))
        x: int = int(130*self.ratio)
        y: int = int(75*self.ratio)

        self.choices = []
        volume_choices: tuple[tuple[str, Callable[[float], None], float], ...] = (
            ("1. General Volume", lambda value: game.change_volume("general", value/100), int(game.general_volume*100)),
            ("2. Music Volume", lambda value: game.change_volume("music", value/100), int(game.music_volume*100)),
        )
        for name, action, default in volume_choices:
            self.choices.append(ChoiceBar(name, x, y, int(15*self.ratio), self.ratio, action, default))
            y += int(33*self.ratio)

        self.choices.append(ChoiceBox("3. Collisons Sound", x, y, int(15*self.ratio), lambda value: game.set_collision_sound(value), game.collision_sound))
        y += int(33*self.ratio)
        self.choices.append(Choice("4. Back", x, y, int(15*self.ratio), lambda: self.back()))

        self.fairy = Fairy(self.sprites, int(100*self.ratio), self.choices[0].rectangle.y, limit=len(self.choices)-1)

    def draw(self, surface: Surface) -> None:
        surface.blit(self.sprites["background"], get_center(self.sprites["background"]))
        self.menu_title.draw(surface)
        for choice in self.choices:
            choice.draw(surface)
        self.fairy.draw(surface)

    def action(self, events: list[Event]) -> None:
        for event in events:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN and self.fairy.position < self.fairy.limit:
                    self.fairy.position += 1
                    self.fairy.move(self.choices[self.fairy.position].rectangle.y)

                elif event.key == pygame.K_UP and self.fairy.position > 0:
                    self.fairy.position -= 1
                    self.fairy.move(self.choices[self.fairy.position].rectangle.y)

                elif event.key == pygame.K_RETURN or event.key == pygame.K_SPACE:
                    self.choices[self.fairy.position].activity(events)

                elif event.key == pygame.K_ESCAPE:
                    self.back()
                    return
        if pygame.key.get_pressed()[pygame.K_RIGHT]:
            current_choice: Choice = self.choices[self.fairy.position]
            if isinstance(current_choice, ChoiceBar):
                current_choice.value += 1

        elif pygame.key.get_pressed()[pygame.K_LEFT]:
            current_choice: Choice = self.choices[self.fairy.position]
            if isinstance(current_choice, ChoiceBar):
                current_choice.value -= 1
        self.fairy.activity(events)

    def play(self, channel: 'Channel', loops: int = -1):
        super().play(channel, loops=loops)

    def back(self):
        from references import game
        game.menu = self.parent
