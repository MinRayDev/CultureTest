import string
from tokenize import String
from typing import Final

import pygame
from pygame import Surface
from pygame.event import Event

from core.sound import Sound
from ui.element.impl.outlined_text import OutlinedText
from ui.menu.game_menu import GameMenu


class TextBox(GameMenu):
    text: OutlinedText
    frame: Surface
    x: int
    y: int
    last: bool
    limit: Final[int] = 75
    allowed_characters: Final[list[str]] = string.ascii_letters + string.digits + " ?!.,;:()"

    def __init__(self, content: str, surface: Surface, last: bool = False):
        super().__init__(r"./resources/menu/textbox")

        if len(content) > TextBox.limit:
            raise ValueError("The content of the text box cannot be longer than 75 characters.")

        color: tuple[int, int, int] = (240, 240, 240)
        if last:
            color = (40, 40, 255)

        self.text = OutlinedText(content, 0, 0, (255, 255, 255), color, 30)
        self.frame = self.sprites["frame"]

        self.x = surface.get_width() // 2 - self.frame.get_width() // 2
        self.y = surface.get_height() // 2 - self.frame.get_height() // 2

        self.last = last

        self.text.rectangle.x = surface.get_width() // 2 - self.text.rectangle.width // 2
        self.text.rectangle.y = self.y + (7*4)
        if last:
            Sound.item_get.play()
        else:
            Sound.message.play()

    def draw(self, surface: Surface) -> None:
        surface.blit(self.frame, (self.x, self.y))
        self.text.draw(surface)

    def action(self, events: list[Event]) -> None:
        import references
        if pygame.key.get_pressed()[pygame.K_ESCAPE]:
            if self.last:
                pass
            else:
                references.game.menu = None
                Sound.message_finish.play()
