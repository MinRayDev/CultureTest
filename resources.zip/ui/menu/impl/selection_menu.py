from typing import TYPE_CHECKING, Optional

import pygame
from pygame import Surface
from pygame.event import Event

from ui.element.impl.outlined_text import OutlinedText
from ui.element.impl.choice import Choice
from ui.element.impl.fairy import Fairy
from ui.menu.impl.question_menu import QuestionMenu
from ui.menu.impl.settings_menu import SettingsMenu
from ui.menu.menu import Menu
from utils.sprites import get_center

if TYPE_CHECKING:
    from pygame.mixer import Channel


class SelectionMenu(Menu):
    ratio: float
    menu_title: OutlinedText
    choices: list[Choice]
    fairy: Fairy

    def __init__(self, parent: Optional['Menu']):
        from references import client
        self.ratio = client.surface.get_height()/224
        super().__init__(parent, "./resources/menu/selection", ratio=self.ratio)
        self.menu_title = OutlinedText("ECRAN DE SELECTION", int(112*self.ratio), int(23*self.ratio), (255, 255, 255), (0, 0, 200), int(15*self.ratio))
        x: int = int(130*self.ratio)
        y: int = int(75*self.ratio)
        self.choices = []
        for name, action in (("1. Start", lambda: self.start()), ("2. Questions", lambda: self.questions()), ("3. Settings", lambda: self.settings()), ("4. Quit", lambda: self.quit())):
            self.choices.append(Choice(name, x, y, int(15*self.ratio), action))
            y += int(33*self.ratio)
        self.fairy = Fairy(self.sprites, int(100*self.ratio), self.choices[0].rectangle.y)

    def draw(self, surface: Surface) -> None:
        surface.blit(self.sprites["background"], get_center(self.sprites["background"]))
        self.menu_title.draw(surface)
        for choice in self.choices:
            choice.draw(surface)
        self.fairy.draw(surface)

    def action(self, events: list[Event]) -> None:
        for event in events:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN and self.fairy.position < self.fairy.limit:
                    self.fairy.position += 1
                    self.fairy.move(self.choices[self.fairy.position].rectangle.y)

                elif event.key == pygame.K_UP and self.fairy.position > 0:
                    self.fairy.position -= 1
                    self.fairy.move(self.choices[self.fairy.position].rectangle.y)

                elif event.key == pygame.K_RETURN or event.key == pygame.K_SPACE:
                    self.choices[self.fairy.position].activity(events)
        self.fairy.activity(events)

    def play(self, channel: 'Channel', loops: int = -1):
        super().play(channel, loops=loops)

    @classmethod
    def start(cls):
        from references import game
        game.menu = None

    def questions(self):
        from references import game
        game.menu = QuestionMenu(self)

    def settings(self):
        from references import game
        game.menu = SettingsMenu(self)

    @classmethod
    def quit(cls):
        from references import game
        game.run = False
