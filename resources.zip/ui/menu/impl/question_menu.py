from typing import TYPE_CHECKING, Optional

import pygame
from pygame import Surface
from pygame.event import Event

from ui.element.impl.choice import Choice
from ui.element.impl.fairy import Fairy
from ui.element.impl.outlined_text import OutlinedText
from ui.menu.menu import Menu
from utils.sprites import get_center

if TYPE_CHECKING:
    from pygame.mixer import Channel


class QuestionMenu(Menu):
    ratio: float
    menu_title: OutlinedText
    choices: list[Choice]
    choices_draw: list[Choice]
    fairy: Fairy
    default_y: int

    def __init__(self, parent: Optional['Menu']):
        from references import client
        self.ratio = client.surface.get_height()/224
        super().__init__(parent, "./resources/menu/question_list", ratio=self.ratio)
        self.menu_title = OutlinedText("ECRAN DES QUESTIONS", int(112*self.ratio), int(23*self.ratio), (255, 255, 255), (0, 0, 200), int(15*self.ratio))
        x: int = int(130*self.ratio)
        y: int = int(75*self.ratio)
        self.default_y = y
        self.choices = [Choice("Ajouter", x, y, int(15*self.ratio), action=lambda: self.add())]
        self.choices[0].outline_color = (0, 150, 0)
        y += int(33*self.ratio)
        from references import game
        for question in game.questions:
            self.choices.append(Choice(question.text, x, y, int(15*self.ratio)))
            y += int(33*self.ratio)
        self.choices_draw = self.choices[:4]
        self.fairy = Fairy(self.sprites, int(100*self.ratio), self.choices[0].rectangle.y, limit=len(self.choices) - 1)

    def draw(self, surface: Surface) -> None:
        self.menu_title.draw(surface)
        for choice in self.choices_draw:
            choice.draw(surface)
        self.fairy.draw(surface)
        surface.blit(self.sprites["foreground"], get_center(self.sprites["foreground"]))

    def action(self, events: list[Event]) -> None:
        for event in events:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN and self.fairy.position < self.fairy.limit:
                    self.fairy.position += 1
                    if self.fairy.relative_position < 3:
                        self.fairy.relative_position += 1
                    else:
                        self.choices_draw = self.choices[self.fairy.position - 3:self.fairy.position+1]
                        y = self.default_y
                        for choice in self.choices_draw:
                            choice.y = y
                            y += int(33*self.ratio)
                    self.fairy.move(self.fairy.relative_position * int(33*self.ratio) + self.default_y)

                elif event.key == pygame.K_UP and self.fairy.position > 0:
                    self.fairy.position -= 1
                    if self.fairy.relative_position > 0:
                        self.fairy.relative_position -= 1
                    else:
                        self.choices_draw = self.choices[self.fairy.position:self.fairy.position + 4]
                        y = self.default_y
                        for choice in self.choices_draw:
                            choice.y = y
                            y += int(33*self.ratio)
                    self.fairy.move(self.choices[self.fairy.position].rectangle.y)

                elif event.key == pygame.K_RETURN or event.key == pygame.K_SPACE:
                    self.choices[self.fairy.position].activity(events)

                elif event.key == pygame.K_ESCAPE:
                    self.back()
        self.fairy.activity(events)

    def play(self, channel: 'Channel', loops: int = -1):
        super().play(channel, loops=loops)

    def back(self):
        from references import game
        game.menu = self.parent

    def add(self):
        from references import game
        from ui.menu.impl.add_menu import AddMenu
        game.menu = AddMenu(self)
