from typing import TYPE_CHECKING, Optional

import pygame
from pygame import Surface
from pygame.event import Event

from ui.element.impl.choice import Choice
from ui.element.impl.fairy import Fairy
from ui.element.impl.outlined_text import OutlinedText
from ui.element.impl.choice_text import ChoiceText
from ui.menu.menu import Menu
from utils.sprites import get_center

if TYPE_CHECKING:
    from pygame.mixer import Channel


class AddMenu(Menu):
    ratio: float
    menu_title: OutlinedText
    choices: list[Choice]
    choices_draw: list[Choice]
    fairy: Fairy
    default_y: int
    answers: tuple[ChoiceText, ChoiceText, ChoiceText]

    def __init__(self, parent: Optional['Menu']):
        from references import client
        self.ratio = client.surface.get_height()/224
        super().__init__(parent, "./resources/menu/add_question", ratio=self.ratio)
        self.menu_title = OutlinedText("ECRAN D'AJOUTS DE QUESTIONS", int(112*self.ratio), int(38*self.ratio), (255, 255, 255), (0, 0, 200), int(15*self.ratio))
        y: int = int(123*self.ratio)
        self.default_y = y
        self.choices = []
        x: int = int(130*self.ratio)
        height: int = int(15*self.ratio)
        self.answers = (
            ChoiceText("Reponse 1", x, y, height),
            ChoiceText("Reponse 2", x, y + int(26*self.ratio), height),
            ChoiceText("Reponse 3", x, y + int(54*self.ratio), height)
        )
        self.choices += self.answers
        self.fairy = Fairy(self.sprites, int(100*self.ratio), self.answers[0].rectangle.y, limit=len(self.answers) - 1)

    def draw(self, surface: Surface) -> None:
        self.menu_title.draw(surface)
        self.fairy.draw(surface)
        for i, choice in enumerate(self.choices):
            selected: bool = False
            if i == self.fairy.position:
                selected = True
            choice.draw(surface, selected=selected)
        surface.blit(self.sprites["foreground"], get_center(self.sprites["foreground"]))

    def action(self, events: list[Event]) -> None:
        for event in events:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN and self.fairy.position < self.fairy.limit:
                    self.fairy.position += 1
                    self.fairy.move(self.choices[self.fairy.position].rectangle.y)

                elif event.key == pygame.K_UP and self.fairy.position > 0:
                    self.fairy.position -= 1
                    self.fairy.move(self.choices[self.fairy.position].rectangle.y)

                elif event.key == pygame.K_ESCAPE:
                    self.back()
        self.answers[self.fairy.position].activity(events)
        self.fairy.activity(events)

    def play(self, channel: 'Channel', loops: int = -1):
        super().play(channel, loops=loops)

    def back(self):
        from references import game
        game.menu = self.parent
