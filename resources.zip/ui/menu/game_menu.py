from ui.menu.menu import Menu


class GameMenu(Menu):
    def __init__(self, resources_path: str):
        super().__init__(resources_path)
