from time import sleep, time
from typing import Optional, TYPE_CHECKING

import pygame
from pygame import Surface

import references
from core.collision_type import CollisionType
from core.facing import Facing
from core.sound import Sound
from entities.entity import Entity
from references import game, client
from ui.color_reference import ColorReference
from ui.menu.impl.text_box import TextBox
from utils.sprites import get_coordinates_with_scroll
from utils.time_util import times, has_elapsed

if TYPE_CHECKING:
    from entities.screen import Screen


class Player(Entity):
    current_key: str
    ghost: bool
    motion_ratio: int
    motions: dict[Facing, int]
    __life: int
    velocity: int
    facing: Facing

    def __init__(self, x: int, y: int):
        super().__init__("Player", r"C:\Users\Gekota\Documents\Dev\Python\CultureTest\resources\player", x, y)
        self.current_sprite = self.sprites["bottom_idle"]
        self.current_key = "bottom_idle"
        self.ghost = False
        self.motion_ratio = 8
        self.motions = {Facing.NORTH: 0, Facing.EAST: 0, Facing.SOUTH: 0, Facing.WEST: 0}
        self.__life = 3
        self.velocity = 2
        self.facing = Facing.SOUTH
        self.counter = {}

    def draw(self, surface: Surface) -> None:
        if not self.ghost:
            from utils.sprites import draw_with_scroll
            draw_with_scroll(surface, self.sprites["shadow"], self.x + self.width // 2 - self.sprites["shadow"].get_width() // 2, self.y + self.height - 20)
        super().draw(surface)

    @property
    def life(self) -> int:
        return self.__life

    @life.setter
    def life(self, value: int) -> None:
        if value < self.__life:
            Sound.hurt.play()
        self.__life = value
        game.hud.set_life(value)
        if value == 0:
            Sound.dies.play()
            sleep(1)
            game.game_over()

    def stop(self) -> None:
        self.motions = {Facing.NORTH: 0, Facing.EAST: 0, Facing.SOUTH: 0, Facing.WEST: 0}
        self.current_key = f"{str(self.facing)}_idle"
        self.current_sprite = self.sprites[self.current_key]

    def move(self, facing: Facing) -> None:
        screen_movement: Optional[CollisionType] = None
        motion_x: int = 0
        motion_y: int = 0
        self.facing = facing
        match facing:
            case Facing.EAST:
                motion_x = self.velocity
            case Facing.WEST:
                motion_x = -self.velocity
            case Facing.SOUTH:
                motion_y = self.velocity
            case Facing.NORTH:
                motion_y = -self.velocity

        if not self.ghost:
            screen_movement: CollisionType = self.collide(motion_x, motion_y, facing)
            if screen_movement == CollisionType.collision:
                if has_elapsed(times.get("collision", 0), 1):
                    times["collision"] = time()
                    if references.game.collision_sound:
                        Sound.bounce.play()
                    self.stop()
                return
        if self.motions[facing] > 8 * self.motion_ratio:
            self.motions[facing] = 1
        self.motions[facing] += 1
        index_ = round(self.motions[facing] // self.motion_ratio)
        if index_ == 0:
            index_ = 1
        self.current_key = f"{str(self.facing)}_{index_}"
        self.current_sprite = self.sprites[self.current_key]

        self.x += motion_x
        self.y += motion_y

        self.compute_scroll(motion_x, motion_y)
        if screen_movement is not None:
            self.change_screen(screen_movement)

    def interact(self) -> None:
        current_screen: Screen = game.screen
        x_offset, y_offset = current_screen.get_offset()
        surface: Optional[Surface] = None
        mask_offset: tuple[float, float] = (0, 0)
        match self.facing:
            case Facing.NORTH:
                surface = Surface((self.width+1, 2))
                mask_offset = (
                    self.x + x_offset,
                    self.y + y_offset - 2
                )
            case Facing.EAST:
                surface = Surface((2, self.height+1))
                mask_offset = (
                    self.x + self.width + x_offset,
                    self.y + y_offset
                )
            case Facing.SOUTH:
                surface = Surface((self.width+1, 2))
                mask_offset = (
                    self.x + x_offset,
                    self.y + self.height + y_offset
                )
            case Facing.WEST:
                surface = Surface((2, self.height+1))
                mask_offset = (
                    self.x + x_offset - 2,
                    self.y + y_offset
                )
        surface.fill((255, 0, 0, 255))
        mask: pygame.mask.Mask = pygame.mask.from_surface(surface)
        for i, mask_name in enumerate(ColorReference.get_interactions()):
            if current_screen.masks[mask_name.get_name()].overlap(mask, mask_offset):
                self.read(i)
                return

    @classmethod
    def read(cls, read_type: int) -> None:
        content: str
        last: bool = False
        if read_type == 0:
            content = "Exemple: Prenez le premier tronc d'arbre a gauche." if game.question is None else game.question.text
        elif read_type == 4:
            content = f"Bravo, vous avez fini le jeu avec un score de {game.good_answers} sur {len(game.questions)}."
            last = True
        else:
            correct_answer: str = [key for key, value in game.question.answers.items() if value][0]
            answers: list[str] = list(game.question.answers.keys())
            answers.remove(correct_answer)
            i: float = 0
            match game.question.correct:
                case 1:
                    i = 1
                case 2:
                    i = 0.5
                case 3:
                    i = 0
            if read_type == game.question.correct:
                content = correct_answer
            else:
                if i == 0.5:
                    if read_type == 1:
                        content = list(game.question.answers.keys())[read_type]
                    else:
                        content = list(game.question.answers.keys())[read_type - 1]
                else:
                    content = list(game.question.answers.keys())[int(read_type - i)]
        game.menu = TextBox(content, client.surface, last)

    def compute_scroll(self, x: int, y: int) -> None:
        if not game.screen.border:
            game.scroll[0] -= x
            game.scroll[1] -= y
            return

        x_offset, y_offset = game.screen.get_offset()
        gsw, gsh = client.surface.get_size()
        sw, sh = game.screen.background.get_size()
        x__, y__ = get_coordinates_with_scroll(self.current_sprite, self.x - x, self.y - y)
        x_mid: int = self.x + self.width // 2
        y_mid: int = self.y + self.height // 2
        screen_borders: tuple[int, int, int, int] = (
            y_mid - gsh // 2,
            x_mid + gsw // 2,
            y_mid + gsh // 2,
            x_mid - gsw // 2
        )
        surface_borders: tuple[int, int, int, int] = (
            - y_offset,
            sw - x_offset,
            sh - y_offset,
            - x_offset
        )
        if x == 0 and y == 0:
            if x__ == 0:
                if screen_borders[Facing.EAST] >= surface_borders[Facing.EAST]:
                    game.scroll[0] += screen_borders[Facing.EAST] - surface_borders[Facing.EAST]

                if screen_borders[Facing.WEST] <= surface_borders[Facing.WEST]:
                    game.scroll[0] += screen_borders[Facing.WEST] - surface_borders[Facing.WEST]

            if y__ == 0:
                if screen_borders[Facing.NORTH] <= surface_borders[Facing.NORTH]:
                    game.scroll[1] += screen_borders[Facing.NORTH] - surface_borders[Facing.NORTH]

                if screen_borders[Facing.SOUTH] >= surface_borders[Facing.SOUTH]:
                    game.scroll[1] += screen_borders[Facing.SOUTH] - surface_borders[Facing.SOUTH]
            return

        error_margin: tuple[int, ...] = tuple(range(-self.velocity//2, self.velocity//2))
        if x__ in error_margin:
            if self.facing == Facing.EAST:
                screen_border: int = screen_borders[Facing.EAST]
                if screen_border > surface_borders[Facing.EAST]:
                    screen_border = surface_borders[Facing.EAST]
                if screen_border < surface_borders[Facing.EAST]:
                    game.scroll[0] -= x

            if self.facing == Facing.WEST:
                screen_border: int = screen_borders[Facing.WEST]
                if screen_border < surface_borders[Facing.WEST]:
                    screen_border = surface_borders[Facing.WEST]
                if screen_border > surface_borders[Facing.WEST]:
                    game.scroll[0] -= x

        if y__ in error_margin:
            if self.facing == Facing.NORTH:
                screen_border: int = screen_borders[Facing.NORTH]
                if screen_border < surface_borders[Facing.NORTH]:
                    screen_border = surface_borders[Facing.NORTH]
                if screen_border > surface_borders[Facing.NORTH]:
                    game.scroll[1] -= y

            if self.facing == Facing.SOUTH:
                screen_border: int = screen_borders[Facing.SOUTH]
                if screen_border > surface_borders[Facing.SOUTH]:
                    screen_border = surface_borders[Facing.SOUTH]
                if screen_border < surface_borders[Facing.SOUTH]:
                    game.scroll[1] -= y

    def change_screen(self, screen_movement: CollisionType) -> None:
        if screen_movement != CollisionType.backward:
            if game.question is not None:
                game.question.past = True
                game.question = None
                if screen_movement == CollisionType.bad_forward:
                    self.life -= 1
                else:
                    Sound.secret.play()
                    game.good_answers += 1
            custom: Optional[list[list[int]]] = game.screen.custom
            game.next_screen()
            self.x, self.y = game.screen.px, game.screen.py
            if custom is not None and self.x == 0 and self.y == 0:
                index_ = 0
                addons = game.screen.addons.copy()
                if len(addons) > 0:
                    index_ = int(addons[-1].strip("addon")) - 1
                if len(custom) == 1:
                    index_ = 0
                coos = custom[index_]
                self.x = coos[0]
                self.y = coos[1]
            game.scroll = [-self.x, -self.y]
            self.compute_scroll(0, 0)
        else:
            game.previous_screen()
            self.x = game.screen.px
            self.y = game.screen.py
            game.scroll = [-game.screen.px, -game.screen.py]
            self.compute_scroll(0, 0)
        Sound.screen_switch.play()
