import os
from typing import Optional

import pygame
from pygame import Surface, image


def load(dir_path: str) -> dict[str, Surface]:
    """Loads the sprites from the given directory path.

        :param dir_path: The directory path of the sprites.
        :type dir_path: str.

        :return: The sprites.
        :rtype: dict[str, Surface].

    """
    sprites = {}
    for file in os.listdir(dir_path):
        if os.path.isfile(rf"{dir_path}\{file}") and (file.endswith(".png") or file.endswith(".jpg")):
            sprites[file[:-4]] = image.load(rf"{dir_path}\{file}").convert_alpha()
    return sprites


def load_sprite(file_path: str) -> Surface:
    """Loads the sprite from the given file path.

        :param file_path: The file path of the sprite.
        :type file_path: str.

        :return: The sprite.
        :rtype: Surface.

    """
    return image.load(file_path).convert_alpha()


def resize(to_resize: Surface, ratio: float) -> Surface:
    """Resizes the given surface by the given ratio.

        :param to_resize: The surface to resize.
        :type to_resize: Surface.

        :param ratio: The ratio to resize the surface by.
        :type ratio: float.

    """
    return pygame.transform.scale(to_resize, (to_resize.get_width() * ratio, to_resize.get_height() * ratio))


def reverse(sprites: dict[str, Surface]) -> dict[str, Surface]:
    """Reverses the given sprites.

        :param sprites: The sprites to reverse.
        :type sprites: dict[str, Surface].

        :return: The reversed sprites.
        :rtype: dict[str, Surface].

    """
    reversed_sprites = {}
    for sprite_name, sprite in sprites.items():
        reversed_sprites[sprite_name] = pygame.transform.flip(sprite, True, False)
    return reversed_sprites


def get_coordinates_with_scroll(surface: Surface, x: int, y: int, parallax_ratio: float = 1) -> tuple[int, int]:
    """Get the coordinates with the scroll of the current level.

        :param surface:
        :param x: The x position to draw at.
        :type x: int.
        :param y: The y position to draw at.
        :type y: int.
        :param parallax_ratio: The parallax ratio.
        :type parallax_ratio: float.

        :return: The coordinates.
        :rtype: tuple[int, int].

    """
    import references
    return (
        x + surface.get_width() // 2 + int(references.game.scroll[0] * parallax_ratio) - references.game.player.width // 2,
        y + surface.get_height() // 2 + int(references.game.scroll[1] * parallax_ratio) - references.game.player.height // 2
    )


def draw_with_scroll(surface: Surface, to_draw: Surface, x: int, y: int, parallax_raito: float = 1) -> None:
    """Draws a surface with the scroll of the current level.

        :param surface: The surface to draw on.
        :type surface: Surface.
        :param to_draw: The surface to draw.
        :type to_draw: Surface.
        :param x: The x position to draw at.
        :type x: int.
        :param y: The y position to draw at.
        :type y: int.
        :param parallax_raito: The parallax ratio.
        :type parallax_raito: float.

    """
    surface.blit(to_draw, get_coordinates_with_scroll(surface, x, y, parallax_raito))


def get_center(element: Surface | pygame.Rect) -> tuple[int, int]:
    import references
    width: Optional[int] = None
    height: Optional[int] = None
    if isinstance(element, pygame.Rect):
        width = element.width
        height = element.height
    elif isinstance(element, Surface):
        width = element.get_width()
        height = element.get_height()
    if width is None or height is None:
        raise TypeError("Element must be pygame.Rect or pygame.Surface")
    return (
        references.client.surface.get_width() // 2 - width // 2,
        references.client.surface.get_height() // 2 - height // 2
    )


def get_shine_pos(x: int, y: int, surface_x: int, surface_y: int, ratio: float) -> tuple[int, int]:
    return (
        int(x*ratio) + surface_x,
        int(y*ratio) + surface_y
    )
