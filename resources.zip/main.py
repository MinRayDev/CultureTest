import pygame

import references
from entities.player import Player
from ui.menu.impl.main_menu import MainMenu
from ui.menu.impl.selection_menu import SelectionMenu

if __name__ == '__main__':
    references.game.menu = SelectionMenu(None)
    references.game.player = Player(0, 0)
    references.game.loop()
    pygame.quit()

