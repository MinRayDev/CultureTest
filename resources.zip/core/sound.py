import enum
import os

import pygame


class Sound(enum.Enum):
    message = pygame.mixer.Sound("./resources/sounds/message.wav")
    message_finish = pygame.mixer.Sound("./resources/sounds/message_finish.wav")
    dies = pygame.mixer.Sound("./resources/sounds/dies.wav")
    hurt = pygame.mixer.Sound("./resources/sounds/hurt.wav")
    bounce = pygame.mixer.Sound("./resources/sounds/bounce.wav")
    screen_switch = pygame.mixer.Sound("./resources/sounds/screen_switch.wav")
    secret = pygame.mixer.Sound("./resources/sounds/secret.wav")
    item_get = pygame.mixer.Sound("./resources/sounds/item_get.wav")

    def get(self):
        return self.value

    def play(self):
        pygame.mixer.Sound.play(self.value)

    @staticmethod
    def stop():
        pygame.mixer.stop()

    @staticmethod
    def set_volume(volume: float):
        for sound in Sound:
            sound.value.set_volume(volume)

    @staticmethod
    def load_sounds(path: str) -> dict[str, pygame.mixer.Sound]:
        sounds: dict[str, pygame.mixer.Sound] = {}
        for file in os.listdir(path):
            if file.endswith(".wav") or file.endswith(".mp3"):
                sounds[file[:-4]] = pygame.mixer.Sound(os.path.join(path, file))
        return sounds
