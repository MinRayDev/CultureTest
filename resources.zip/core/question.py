import json
import os
import random
from typing import Optional


class QuestionEncoder(json.JSONEncoder):
    def default(self, o: 'Question') -> dict[str, str | dict[str, bool]]:
        return o.to_json()


class Question:
    text: str
    answers: dict[str, bool]
    correct: int
    past: bool

    def __init__(self, text: str, answers: dict[str, bool]):
        self.text = text
        self.answers = answers
        self.correct = random.randint(1, len(answers))
        self.past = False

    def to_json(self) -> dict[str, str | dict[str, bool]]:
        return {"text": self.text, "answers": self.answers}


class QuestionManager:
    questions: list[Question]
    question: Optional[Question]

    def __init__(self):
        self.questions = self.load_questions()
        self.question = None

    def create_question(self, text: str, answers: dict[str, bool]) -> 'Question':
        question: Question = Question(text, answers)
        self.questions.append(question)
        json.dump(self.questions, open(os.path.join(os.getcwd(), "resources", "questions.json"), "w"),
                  cls=QuestionEncoder)
        return question

    @classmethod
    def load_questions(cls) -> list['Question']:
        questions: list['Question'] = []
        for question in json.load(open(os.path.join(os.getcwd(), "resources", "questions.json"), "r")):
            questions.append(Question(**question))
        return questions

    def get_question(self) -> Optional['Question']:
        if len(self.questions) == 0:
            raise Exception("No questions loaded")
        if all(question.past for question in self.questions):
            return None
        while True:
            question: 'Question' = random.choice(self.questions)
            if not question.past:
                return question
