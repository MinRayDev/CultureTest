import sys

t: list[int] = [0, 1]
t1 = 0
t2 = 0

print(sys.getsizeof(t))
print(sys.getsizeof(t1))
print(sys.getsizeof(t2))